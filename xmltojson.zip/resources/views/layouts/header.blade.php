<header class="p-3 d-flex justify-content-end flex-wrap">
    <div>
        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#button-one-modal">Button 1</button>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#button-two-modal">Button 2</button>
    </div>
</header>
