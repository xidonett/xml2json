<?php $__env->startSection('content'); ?>
    <section class="d-flex justify-content-between flex-wrap text-center p-5">
        <div class="language-block">
            <h2 class="language-block__title">JSON</h2>
            <textarea class="form-control parsing-data" disabled></textarea>
            <button class="btn btn-warning mt-2 choose-btn">Choose <span class="choose-btn__file-type">JSON</span> file</button>
            <input type="file" name="file" class="parsing-file" accept=".json">
        </div>
        <div class="d-flex flex-wrap align-items-center ml-5">
            <div class="d-flex justify-content-center align-items-middle w-100 mt-5">
                <button class="btn btn-secondary btn-lg exchange-btn"><i class="fas fa-exchange-alt"></i></button>
            </div>
            <div class="d-flex align-items-end justify-content-center w-100">
                <button class="btn btn-success btn-lg start-btn">Start</button>
                <a href="/" class="btn btn-danger btn-lg reset-btn">Reset</a>
            </div>
        </div>
        <div class="language-block">
            <h2 class="language-block__title">XML <i class="fas fa-spinner fa-pulse loading"></i></h2>
            <form action="<?php echo e(route('api.download')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="filename" class="converted__filename" value="file">
                <input type="hidden" name="extension" class="converted__extension" value="xml">
                <textarea class="form-control parsing-result" name="converted" readonly></textarea>
                <button class="btn btn-primary btn-md mt-2 save-btn" type="submit">Save</button>
            </form>
        </div>
    </section>
    <?php echo $__env->make('components.modals.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.modals.button-one', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.modals.button-two', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmltojson\resources\views/index.blade.php ENDPATH**/ ?>