<div class="modal fade" id="button-one-modal" tabindex="-1" aria-labelledby="button-one-modal__title" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="button-one-modal__title">Button one</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body button-one-modal__content">
                Some important content for the first button...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\xmltojson\resources\views/components/modals/button-one.blade.php ENDPATH**/ ?>